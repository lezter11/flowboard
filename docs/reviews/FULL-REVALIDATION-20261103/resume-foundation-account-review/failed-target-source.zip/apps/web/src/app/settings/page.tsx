'use client';

import { Suspense, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { api, ApiError } from '@/lib/api';
import { canLeave, describeLeaveFailure, leaveCopy } from '@/lib/leave-project';
import { useRouter } from '@/lib/guarded-router';
import { describeError } from '@/lib/errors';
import { canEditBoardDetails } from '@/lib/member-controls';
import { can, normalizeRole, ROLE_META } from '@/lib/roles';
import { useProjectBoards } from '@/lib/portfolio';
import { useSession } from '@/lib/session';
import { usePollKeys } from '@/components/polling';
import { Icon } from '@/components/ui/icon';
import { WorkspacePreferences } from '@/components/ui/workspace-preferences';
import { Avatar } from '@/components/ui/avatar';
import { useToast } from '@/components/ui/toasts';
import { useShell } from '@/components/shell/shell-context';
import { memoryDrafts } from '@/lib/memory-drafts';
import { useMemoryValue, useMemoryRef, useMemoryDirty } from '@/lib/use-memory-draft';
import { ErrorNote } from '@/components/ui/error-note';
import { DialogLayer } from '@/components/ui/dialog-layer';
import { ColumnsDialog } from '@/components/board/columns-dialog';

type Tab = 'project' | 'board' | 'account' | 'workspace' | 'appearance';
const TABS: Array<[Tab, string]> = [['project', 'Project'], ['board', 'Board and columns'], ['account', 'Account'], ['workspace', 'Workspace'], ['appearance', 'Appearance']];

function SettingsScreen() {
  const params = useSearchParams();
  const { state, refetch, signOut } = useSession();
  const shell = useShell();
  const toast = useToast();
  const queryClient = useQueryClient();
  const router = useRouter();
  const initial = params.get('tab');
  const [tab, setTab] = useState<Tab>(TABS.some(([id]) => id === initial) ? (initial as Tab) : 'project');
  const projects = useMemo(() => (state.status === 'ready' ? state.session.accessibleProjects : []), [state]);
  const sessionActorId=state.status==='ready'?state.session.actor.id:'';
  const [rememberedProject,setRememberedProject]=useMemoryValue(['settings-context',sessionActorId,'project'],'');
  const explicitProject=params.get('project')??rememberedProject;
  const project = explicitProject?projects.find((p)=>p.id===explicitProject):projects[0];
  useEffect(()=>{if(!rememberedProject&&project)setRememberedProject(project.id);},[rememberedProject,project?.id]);
  const role = normalizeRole(project?.role);
  const editable = can(role, 'manageBoard') && !project?.isArchived;
  const actor = state.status === 'ready' ? state.session.actor : null;

  const scope=['settings',state.status==='ready'?state.session.actor.id:'',project?.id??''];
  const [name, setName] = useMemoryValue([...scope,'name'],'');
  const [description, setDescription] = useMemoryValue([...scope,'description'],'');
  const [projectVersion,setProjectVersion]=useMemoryValue([...scope,'version'],project?.version??0);
  const [projectConflict,setProjectConflict]=useMemoryValue([...scope,'conflict'],false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  // The session is polled, so a colleague's rename arrives here: follow it only for fields the user has not edited.
  const seenRef = useMemoryRef<{ id?: string; name: string; description: string;version?:number }>([...scope,'baseline'],()=>({name:'',description:''}));
  const projectProtection=memoryDrafts.protectFields(scope,{actorId:sessionActorId,projectId:project?.id},{
    name:{scope:[...scope,'name'],base:()=>seenRef.current.name,empty:''},description:{scope:[...scope,'description'],base:()=>seenRef.current.description,empty:''},defaultBoard:{scope:[...scope,'default-board'],base:()=>seenDefault.current,empty:''},
  },()=>{seenRef.current={id:projectIdForDraft,name:'',description:''};seenDefault.current='';setProjectVersion(0);setProjectConflict(true);});
  const projectIdForDraft=project?.id;
  useEffect(() => {
    if(project){const restored=projectProtection.restore({name:project.name,description:project.description??'',defaultBoard:project.defaultBoardId??''});if(restored){seenRef.current={id:project.id,name:project.name,description:project.description??'',version:project.version};seenDefault.current=project.defaultBoardId??'';setProjectVersion(project.version);setProjectConflict(restored.retained);return;}}
    const prev = seenRef.current;
    const same = prev.id === project?.id;
    setName((n) => (!same || n === prev.name ? project?.name ?? '' : n));
    setDescription((d) => (!same || d === prev.description ? project?.description ?? '' : d));
    if(project){const ownValuesSaved=name.trim()===project.name&&description.trim()===(project.description??'')&&defaultBoard===(project.defaultBoardId??'');if(!same||ownValuesSaved||name===prev.name&&description===prev.description&&defaultBoard===seenDefault.current){setProjectVersion(project.version);setProjectConflict(false);}else if(prev.version!==project.version)setProjectConflict(true);}
    seenRef.current = { id: project?.id, name: project?.name ?? '', description: project?.description ?? '',version:project?.version };
  }, [project?.id, project?.name, project?.description,project?.version,project?.role,project?.isArchived]);
  usePollKeys([['boards', project?.id], ['project', project?.id]], !!project);
  const isOwner = role === 'owner';
  const [defaultBoard, setDefaultBoard] = useMemoryValue([...scope,'default-board'],project?.defaultBoardId??'');
  const seenDefault=useMemoryRef([...scope,'default-board-base'],()=>project?.defaultBoardId??'');
  useEffect(()=>{const next=project?.defaultBoardId??'';setDefaultBoard((value)=>value===seenDefault.current?next:value);seenDefault.current=next;},[project?.id,project?.defaultBoardId]);
  const defaultChanged = isOwner && !!project && defaultBoard !== (project.defaultBoardId ?? '');
  const dirty = !!project && (name !== project.name || description !== (project.description ?? '') || defaultChanged);

  const boards = useProjectBoards(project?.id ?? null);
  const [rememberedBoard,setRememberedBoard]=useMemoryValue([...scope,'board-context'],'');
  const requestedBoard=params.get('board')??rememberedBoard;
  const availableBoards=boards.error instanceof ApiError&&[401,403,404].includes(boards.error.status)?[]:boards.data??[];
  const board=requestedBoard?availableBoards.find((b)=>b.id===requestedBoard):availableBoards[0];
  useEffect(()=>{if(!rememberedBoard&&board)setRememberedBoard(board.id);},[rememberedBoard,board?.id]);
  const [boardName, setBoardName] = useMemoryValue([...scope,'board',board?.id,'name'],'');
  const [boardDescription, setBoardDescription] = useMemoryValue([...scope,'board',board?.id,'description'],'');
  const [boardVersion,setBoardVersion]=useMemoryValue([...scope,'board',board?.id,'version'],board?.snapshotVersion??0);
  const [boardConflict,setBoardConflict]=useMemoryValue([...scope,'board',board?.id,'conflict'],false);
  const seenBoard=useMemoryRef<{id?:string;name:string;description:string;version?:number}>([...scope,'board',board?.id,'baseline'],()=>({name:'',description:''}));
  const boardIdForDraft=board?.id;
  const boardScope=[...scope,'board',boardIdForDraft];
  const boardProtection=memoryDrafts.protectFields(boardScope,{actorId:sessionActorId,projectId:projectIdForDraft,boardId:boardIdForDraft},{name:{scope:[...boardScope,'name'],base:()=>seenBoard.current.name,empty:''},description:{scope:[...boardScope,'description'],base:()=>seenBoard.current.description,empty:''}},()=>{seenBoard.current={id:boardIdForDraft,name:'',description:''};setBoardVersion(0);setBoardConflict(true);});
  useEffect(()=>{if(board){const restored=boardProtection.restore({name:board.name,description:board.description??''});if(restored){seenBoard.current={id:board.id,name:board.name,description:board.description??'',version:board.snapshotVersion};setBoardVersion(board.snapshotVersion);setBoardConflict(restored.retained);return;}}const prev=seenBoard.current;setBoardName((value)=>prev.id!==board?.id||value===prev.name?board?.name??'':value);setBoardDescription((value)=>prev.id!==board?.id||value===prev.description?board?.description??'':value);if(board){if(prev.id!==board.id||boardName.trim()===board.name&&boardDescription.trim()===(board.description??'')||boardName===prev.name&&boardDescription===prev.description){setBoardVersion(board.snapshotVersion);setBoardConflict(false);}else if(prev.version!==board.snapshotVersion)setBoardConflict(true);}seenBoard.current={id:board?.id,name:board?.name??'',description:board?.description??'',version:board?.snapshotVersion};},[board?.id,board?.name,board?.description,board?.snapshotVersion]);
  const boardDirty = !!board && (boardName.trim() !== board.name || boardDescription.trim() !== (board.description ?? ''));
  const boardEditable = canEditBoardDetails(role, !!board?.isArchived, !!project?.isArchived);

  const [displayName, setDisplayName] = useMemoryValue(['profile',actor?.id??'','display-name'],'');
  const [nameBusy, setNameBusy] = useState(false);
  const [nameError, setNameError] = useState('');
  const seenActor=useMemoryRef<{id?:string;name:string}>(['profile',actor?.id??'','baseline'],()=>({name:''}));
  const profileActorId=actor?.id;
  const profileProtection=memoryDrafts.protectFields(['profile',profileActorId??''],{actorId:profileActorId??''},{name:{scope:['profile',profileActorId??'','display-name'],base:()=>seenActor.current.name,empty:''}},()=>{seenActor.current={id:profileActorId,name:''};});
  useEffect(()=>{if(actor){const restored=profileProtection.restore({name:actor.displayName});if(restored){seenActor.current={id:actor.id,name:actor.displayName};return;}}const prev=seenActor.current;setDisplayName((value)=>prev.id!==actor?.id||value===prev.name?actor?.displayName??'':value);seenActor.current={id:actor?.id,name:actor?.displayName??''};},[actor?.id,actor?.displayName]);
  const nameDirty = !!actor && displayName.trim() !== actor.displayName;
  const clearProjectDirty=useMemoryDirty([...scope,'dirty'],dirty);
  const clearBoardDirty=useMemoryDirty([...scope,'board',board?.id,'dirty'],boardDirty);
  const clearNameDirty=useMemoryDirty(['profile',actor?.id??'','dirty'],nameDirty);
  const saveName = async (event: FormEvent) => {
    event.preventDefault();
    if(!actor||nameBusy)return;
    const value = displayName.trim();
    if (!value) { setNameError('Enter a display name.'); return; }
    if (/\p{Cc}/u.test(displayName)) { setNameError('A display name cannot contain line breaks or control characters.'); return; }
    if (value.length > 80) { setNameError('A display name can be at most 80 characters.'); return; }
    setNameBusy(true); setNameError('');
    try {
      await api.updateProfile({ displayName: value });
      // The name appears in the rail, people lists, comments and activity: refresh all cached data, not just the session.
      await queryClient.invalidateQueries();
      toast('Name updated', { icon: 'check' });
    } catch (err) { setNameError(describeError(err)); } finally { setNameBusy(false); }
  };
  const [leaveOpen, setLeaveOpen] = useState(false);
  const [leaveBusy, setLeaveBusy] = useState(false);
  const [leaveError, setLeaveError] = useState<unknown>(null);
  const leaveAttempt = useRef<string | null>(null);
  const leave = async () => {
    if (!project || leaveBusy) return;
    setLeaveBusy(true); setLeaveError(null);
    leaveAttempt.current ??= `idemp_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
    try {
      await api.leaveProject(project.id, leaveAttempt.current);
      // Everything cached about the project is now off limits; the session lists what is left.
      queryClient.removeQueries({ predicate: (q) => JSON.stringify(q.queryKey).includes(project.id) });
      await queryClient.invalidateQueries({ queryKey: ['session'] });
      toast(`You left ${project.name}`, { icon: 'check' });
      setLeaveOpen(false);
      router.replace('/projects');
    } catch (err) {
      leaveAttempt.current = null;
      setLeaveError(err);
      refetch();
    } finally { setLeaveBusy(false); }
  };
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [lifecycleBusy, setLifecycleBusy] = useState(false);
  const [lifecycleError, setLifecycleError] = useState('');
  const [columnsOpen, setColumnsOpen] = useState(false);
  // The columns dialog reads the board from the query cache, so make sure it is there.
  useQuery({ queryKey: ['board', board?.id], queryFn: async () => (await api.getBoardSnapshot(board!.id, { cardLimitPerColumn: 1 })).data, enabled: !!board && tab === 'board' });
  const changeLifecycle = async () => {
    if (!project) return;
    setLifecycleBusy(true); setLifecycleError('');
    try {
      if (project.isArchived) await api.reopenProject(project.id, project.version); else await api.archiveProject(project.id, project.version);
      toast(project.isArchived ? 'Project reopened' : 'Project archived. Its boards are now read-only.', { icon: 'check' });
      setArchiveOpen(false);
      await Promise.all([refetch(), queryClient.invalidateQueries({ queryKey: ['project', project.id] }), queryClient.invalidateQueries({ queryKey: ['boards', project.id] })]);
    } catch (err) { setLifecycleError(describeError(err)); refetch(); } finally { setLifecycleBusy(false); }
  };

  const saveProject = async (event: FormEvent) => {
    event.preventDefault();
    if (!project || !dirty || projectConflict || !editable || !actor || busy) return;
    if (!name.trim()) { setError('Enter a project name.'); return; }
    setBusy(true); setError('');
    try {
      await api.updateProject(project.id, {
        name: name.trim(), description: description.trim() || null, expectedVersion: projectVersion,
        // Owner only: Managers leave the landing board to the Owner (the API refuses it with 403).
        ...(defaultChanged ? { defaultBoardId: defaultBoard || null } : {}),
      });
      toast('Project saved', { icon: 'check' });
      refetch();
    } catch (err) { setError(describeError(err)); refetch(); } finally { setBusy(false); }
  };
  const saveBoard = async (event: FormEvent) => {
    event.preventDefault();
    if (!board || !boardDirty || !boardEditable || boardConflict || !actor || busy) return;
    if (!boardName.trim()) { setError('Enter a board name.'); return; }
    setBusy(true); setError('');
    try {
      await api.updateBoard(board.id, {
        ...(boardName.trim() !== board.name ? { name: boardName.trim() } : {}),
        ...(boardDescription.trim() !== (board.description ?? '') ? { description: boardDescription.trim() || null } : {}),
        expectedVersion: boardVersion,
      });
      toast('Board saved', { icon: 'check' });
      await queryClient.invalidateQueries({ queryKey: ['boards', project?.id] });
    } catch (err) { setError(describeError(err)); await queryClient.invalidateQueries({ queryKey: ['boards', project?.id] }); } finally { setBusy(false); }
  };

  return (
    <>
      <div className="page-head">
        <div className="page-head-copy">
          <h1>Settings</h1>
          <p className="page-sub"><span>Project, board, account and appearance</span></p>
        </div>
        <div className="page-actions">
          {project && <Link className="btn" href={`/project?id=${encodeURIComponent(project.id)}`}><Icon name="folder" />Project overview</Link>}
          {board && <Link className="btn ghost" href={`/board?id=${encodeURIComponent(board.id)}`}><Icon name="board" />Open board</Link>}
        </div>
      </div>

      <div className="review-bar">
        <Icon name="lock" />
        <span><strong>{editable ? 'Owners and managers can edit.' : 'Read-only for your role.'}</strong> Theme is saved in this browser.</span>
        <span className="spacer" />
        {project && <span className="badge">{ROLE_META[role].label}</span>}
      </div>

      <div className="tabs settings-tabs" role="tablist" aria-label="Settings sections">
        {TABS.map(([id, label]) => (
          <button key={id} className="tab" type="button" role="tab" id={`tab-${id}`} aria-controls={`panel-${id}`} aria-selected={tab === id} onClick={() => { setTab(id); setError(''); }}>{label}</button>
        ))}
      </div>

      <div className="split-layout">
        <div className="settings-panel stack">
          {tab === 'project' && (
            <section className="panel" id="panel-project" role="tabpanel" aria-labelledby="tab-project">
              <div className="panel-head">
                <div className="panel-head-copy"><h2 className="panel-title">Project settings</h2><p className="panel-sub">{project ? `Name and description for ${project.name}.` : 'No project available.'}</p></div>
                <div className="panel-actions"><span className="badge">{project?.isArchived ? 'Archived' : 'Active'}</span></div>
              </div>
              <div className="panel-body">
                <form className="settings-form" onSubmit={saveProject}>{projectConflict&&project&&<div className="note warn"><p>The project changed. Your values are kept. Current: {project.name} · {project.description??'No description'}</p><button className="btn" type="button" onClick={()=>{setProjectVersion(project.version);setProjectConflict(false);}}>Use latest project version, keep my values</button></div>}
                  <div className="form-grid">
                    <div className="field span-2"><label className="field-label" htmlFor="projectName">Project name</label><input className="control" id="projectName" type="text" maxLength={100} value={name} disabled={!editable} onChange={(event) => setName(event.target.value)} /><p className="field-help">Shown in project lists and navigation.</p></div>
                    <div className="field span-2"><label className="field-label" htmlFor="projectDescription">Description</label><textarea className="control textarea" id="projectDescription" maxLength={2000} value={description} disabled={!editable} onChange={(event) => setDescription(event.target.value)} /><p className="field-help">Plain text, up to 2000 characters.</p></div>
                    <div className="field span-2">
                      <label className="field-label" htmlFor="defaultBoard">Default board</label>
                      <select className="control" id="defaultBoard" value={defaultBoard} disabled={!isOwner || !!project?.isArchived || boards.isPending} onChange={(event) => setDefaultBoard(event.target.value)}>
                        <option value="">None (open the board I used last)</option>
                        {(boards.data ?? []).filter((b) => !b.isArchived).map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                      </select>
                      <p className="field-help">{isOwner ? 'Where the Board button and sign-in take people first. Only boards a person can open are used for them.' : 'Only the project Owner can choose the default board.'}</p>
                    </div>
                  </div>
                  {error && <div className="note warn" role="alert"><Icon name="alert" /><span>{error}</span></div>}
                  <div className="note"><Icon name="shield" /><span>{editable ? 'Owners and managers can rename the project.' : 'Only owners and managers can change project settings.'}</span></div>
                  <div className="form-actions">
                    <span className="dirty-note"><span className="dot" />{dirty ? 'Unsaved changes' : 'No unsaved changes'}</span>
                    <span className="spacer" />
                    {dirty&&project&&<button className="btn" type="button" disabled={busy} onClick={()=>{setName(project.name);setDescription(project.description??'');setDefaultBoard(project.defaultBoardId??'');setProjectVersion(project.version);setProjectConflict(false);clearProjectDirty();}}>Discard project changes</button>}<button className="btn primary" type="submit" disabled={!editable || !dirty || busy || projectConflict}>{busy ? 'Saving…' : 'Save project'}</button>
                  </div>
                </form>
                <div className="divider" />
                <div className="stack-sm">
                  <h3 className="settings-section-title">Project status</h3>
                  <p className="settings-section-sub">Archived projects are read-only. Only the Owner can reopen them.</p>
                  {project?.isArchived && <div className="note" role="status"><Icon name="archive" /><span><strong>This project is archived.</strong> Cards, boards and people cannot be changed until the Owner reopens it. Due dates keep counting.</span></div>}
                  <div className="row">
                    <button className="btn" type="button" disabled={!isOwner || !project || lifecycleBusy} onClick={() => { setLifecycleError(''); setArchiveOpen(true); }} title={isOwner ? undefined : 'Only the project Owner can archive or reopen a project'}><Icon name="archive" />{project?.isArchived ? 'Reopen project' : 'Archive project'}</button>
                    {!isOwner && <span className="field-help">Only the project Owner can archive or reopen a project.</span>}
                  </div>
                </div>
                <div className="divider" />
                <div className="stack-sm">
                  <h3 className="settings-section-title">Leave this project</h3>
                  {canLeave(project)
                    ? <>
                        <p className="settings-section-sub">Leaving removes your access to {project?.name} and its boards. Your own projects are not affected.</p>
                        <div className="row"><button className="btn" type="button" onClick={() => { setLeaveError(null); setLeaveOpen(true); }}><Icon name="arrow-left" />Leave project</button></div>
                      </>
                    : <p className="settings-section-sub">You own this project, so you cannot leave it. Archive it if you no longer need it.</p>}
                </div>
              </div>
            </section>
          )}

          {tab === 'board' && (
            <section className="panel" id="panel-board" role="tabpanel" aria-labelledby="tab-board">
              <div className="panel-head">
                <div className="panel-head-copy"><h2 className="panel-title">Board and columns</h2><p className="panel-sub">{board ? `Board name for ${board.name}.` : 'No board available.'}</p></div>
                <div className="panel-actions"><span className="badge">{board?.isArchived ? 'Archived' : 'Active'}</span></div>
              </div>
              <div className="panel-body">
                <form className="settings-form" onSubmit={saveBoard}>{boardConflict&&board&&<div className="note warn"><p>The board changed. Your values are kept. Current: {board.name} · {board.description??'No description'}</p><button className="btn" type="button" onClick={()=>{setBoardVersion(board.snapshotVersion);setBoardConflict(false);}}>Use latest board version, keep my values</button></div>}
                  <div className="form-grid">
                    <div className="field span-2"><label className="field-label" htmlFor="boardName">Board name</label><input className="control" id="boardName" type="text" maxLength={100} value={boardName} disabled={!boardEditable || !board} onChange={(event) => setBoardName(event.target.value)} /><p className="field-help">{boardEditable ? 'Only the project Owner can rename a board.' : 'Only the project Owner can change a board name or description.'}</p></div>
                    <div className="field span-2"><label className="field-label" htmlFor="boardDescription">Description</label><textarea className="control textarea" id="boardDescription" maxLength={2000} value={boardDescription} disabled={!boardEditable || !board} onChange={(event) => setBoardDescription(event.target.value)} /><p className="field-help">Shown under the board title. Plain text, up to 2000 characters.</p></div>
                  </div>
                  <div className="stack-sm">
                    <div className="row" style={{ justifyContent: 'space-between' }}>
                      <div><h3 className="settings-section-title">Columns</h3><p className="settings-section-sub">Arrange and name the stages of this board.</p></div>
                      <button className="btn sm" type="button" disabled={!board || !editable || board.isArchived} onClick={() => setColumnsOpen(true)} title={editable ? undefined : 'Only owners and managers can edit columns'}><Icon name="columns" />Edit columns</button>
                    </div>
                    <p className="field-help">{editable ? 'Add, rename, recolour, reorder and delete columns in the column editor.' : 'Only owners and managers can edit columns.'}</p>
                  </div>
                  {error && <div className="note warn" role="alert"><Icon name="alert" /><span>{error}</span></div>}
                  <div className="form-actions">
                    <span className="spacer" />
                    {boardDirty&&board&&<button className="btn" type="button" disabled={busy} onClick={()=>{setBoardName(board.name);setBoardDescription(board.description??'');setBoardVersion(board.snapshotVersion);setBoardConflict(false);clearBoardDirty();}}>Discard board changes</button>}<button className="btn primary" type="submit" disabled={!boardEditable || !board || !boardDirty || busy || boardConflict}>{busy ? 'Saving…' : 'Save board'}</button>
                  </div>
                </form>
              </div>
            </section>
          )}

          {tab === 'account' && (
            <section className="panel" id="panel-account" role="tabpanel" aria-labelledby="tab-account">
              <div className="panel-head">
                <div className="panel-head-copy"><h2 className="panel-title">Account</h2><p className="panel-sub">Profile, current project role and project access.</p></div>
                <div className="panel-actions"><span className="badge">{ROLE_META[role].label}</span></div>
              </div>
              <div className="panel-body stack">
                {actor && (
                  <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
                    <Avatar id={actor.id} name={actor.displayName} avatarUrl={actor.avatarUrl} className="xl" />
                    <div className="stack-xs" style={{ flex: 1, minWidth: 0 }}>
                      <h3 className="settings-section-title">{actor.displayName}</h3>
                      <p className="settings-section-sub">{actor.email}</p>
                    </div>
                  </div>
                )}
                <div className="form-grid">
                  <form className="field" onSubmit={saveName} noValidate>
                    <label className="field-label" htmlFor="accountDisplayName">Display name</label>
                    <div className="row" style={{ gap: 8 }}>
                      <input className="control" id="accountDisplayName" type="text" autoComplete="name" value={displayName} maxLength={80} aria-invalid={!!nameError} aria-describedby={nameError ? 'accountNameError' : 'accountNameHelp'} onChange={(event) => { setDisplayName(event.target.value); setNameError(''); }} />
                      {nameDirty&&actor&&<button className="btn" type="button" disabled={nameBusy} onClick={()=>{setDisplayName(actor.displayName);clearNameDirty();}}>Discard name change</button>}<button className="btn primary" type="submit" disabled={nameBusy || !nameDirty}>{nameBusy ? 'Saving…' : 'Save name'}</button>
                    </div>
                    {nameError ? <p className="field-error" id="accountNameError" role="alert">{nameError}</p> : <p className="field-help" id="accountNameHelp">Shown to your team on cards, comments and activity. 1 to 80 characters.</p>}
                  </form>
                  <div className="field"><label className="field-label" htmlFor="accountEmailField">Email</label><input className="control" id="accountEmailField" type="email" value={actor?.email ?? ''} disabled readOnly /><p className="field-help">Your email and avatar come from Google and refresh when you sign in.</p></div>
                </div>
                <div className="divider" />
                <div className="stack-sm">
                  <h3 className="settings-section-title">Project access</h3>
                  <p className="settings-section-sub">Project-only access. Holding a workspace account does not reveal a sibling project.</p>
                  <ul className="pm-branch-list" aria-label="Projects you can open">
                    {projects.map((p) => <li key={p.id} className="pm-branch" style={{ gridTemplateColumns: 'minmax(0,1fr) auto' }}><span className="pm-branch-name">{p.name}</span><span className="badge">{ROLE_META[normalizeRole(p.role)].label}</span></li>)}
                  </ul>
                </div>
                <div className="form-actions"><span className="spacer" /><button className="btn" type="button" onClick={() => void signOut()}>Sign out</button></div>
              </div>
            </section>
          )}

          {tab === 'workspace' && <WorkspacePreferences actorId={actor?.id??''} workspaces={state.status==='ready'?state.session.ownedWorkspaces:[]} currentWorkspaceId={project?.workspaceId} />}

          {tab === 'appearance' && (
            <section className="panel" id="panel-appearance" role="tabpanel" aria-labelledby="tab-appearance">
              <div className="panel-head">
                <div className="panel-head-copy"><h2 className="panel-title">Appearance</h2><p className="panel-sub">Choose the appearance that feels right for you.</p></div>
                <div className="panel-actions"><span className="badge">{shell.theme === 'dark' ? 'Dark' : 'Light'}</span></div>
              </div>
              <div className="panel-body stack">
                <div className="theme-grid" role="group" aria-label="Theme">
                  {(['light', 'dark'] as const).map((choice) => (
                    <button key={choice} className="theme-card" type="button" aria-pressed={shell.theme === choice} onClick={() => { if (shell.theme !== choice) shell.toggleTheme(); }}>
                      <span className={`theme-preview ${choice}`} aria-hidden="true"><span className="theme-preview-bar" /><span className="theme-preview-body"><span className="theme-preview-col" /><span className="theme-preview-col" /><span className="theme-preview-col" /></span></span>
                      <strong>{choice === 'light' ? 'Light' : 'Dark'}</strong>
                      <span>{choice === 'light' ? 'A bright, calm look.' : 'Softer surfaces for low-light work.'}</span>
                    </button>
                  ))}
                </div>
                <div className="note"><Icon name="palette" /><span>Your choice is saved in this browser.</span></div>
              </div>
            </section>
          )}
        </div>
      </div>
      {board && editable && <ColumnsDialog readOnly={!!board.isArchived || !!project?.isArchived} boardId={board.id} open={columnsOpen} onClose={() => setColumnsOpen(false)} />}
      <DialogLayer open={leaveOpen} onClose={() => { if (!leaveBusy) setLeaveOpen(false); }} labelledBy="leaveTitle" describedBy="leaveCopy" role="alertdialog">
        <div className="dialog-head"><div className="dialog-head-copy"><h2 id="leaveTitle">{leaveCopy(project?.name ?? 'this project').title}</h2></div></div>
        <div className="dialog-body">
          <p id="leaveCopy" className="confirm-copy">{leaveCopy(project?.name ?? 'this project').body}</p>
          {leaveError != null && <ErrorNote error={leaveError} ctx={{ role }} focusOnMount onRetry={() => void leave()} />}
        </div>
        <footer className="dialog-foot"><span className="spacer" /><button className="btn" type="button" data-autofocus onClick={() => setLeaveOpen(false)} disabled={leaveBusy}>Stay in project</button><button className="btn danger" type="button" onClick={() => void leave()} disabled={leaveBusy}>{leaveBusy ? 'Leaving…' : leaveCopy(project?.name ?? '').confirm}</button></footer>
      </DialogLayer>
      <DialogLayer open={archiveOpen} onClose={() => { if (!lifecycleBusy) setArchiveOpen(false); }} labelledBy="archiveTitle" describedBy="archiveCopy" role="alertdialog">
        <div className="dialog-head"><div className="dialog-head-copy"><h2 id="archiveTitle">{project?.isArchived ? 'Reopen this project?' : 'Archive this project?'}</h2></div></div>
        <div className="dialog-body">
          <p id="archiveCopy" className="confirm-copy">{project?.isArchived ? `Reopening ${project?.name} lets people create, edit, move and comment on cards again.` : `${project?.name} becomes read-only. Everyone can still read its boards, cards, comments and images, but nobody can add or change anything, invite people or change settings until you reopen it. Due dates keep counting. Nothing is deleted.`}</p>
          {lifecycleError && <p className="form-error" role="alert">{lifecycleError}</p>}
        </div>
        <footer className="dialog-foot"><span className="spacer" /><button className="btn" type="button" data-autofocus onClick={() => setArchiveOpen(false)} disabled={lifecycleBusy}>Cancel</button><button className={`btn ${project?.isArchived ? 'primary' : 'danger'}`} type="button" onClick={() => void changeLifecycle()} disabled={lifecycleBusy}>{lifecycleBusy ? 'Working…' : project?.isArchived ? 'Reopen project' : 'Archive project'}</button></footer>
      </DialogLayer>
    </>
  );
}

export default function SettingsPage() {
  return <Suspense fallback={<div role="status" className="state-note">Loading settings…</div>}><SettingsScreen /></Suspense>;
}
