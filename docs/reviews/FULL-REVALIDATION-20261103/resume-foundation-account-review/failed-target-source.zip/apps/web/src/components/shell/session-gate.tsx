'use client';

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { useRouter } from '@/lib/guarded-router';
import { signinPathFor } from '@/lib/return-path';
import { landingFor } from '@/lib/landing';
import { hasUnsaved } from '@/lib/unsaved';
import { useSession } from '@/lib/session';

/** Pages that handle a signed-out visitor themselves. Everything else needs a session. */
const OPEN_ROUTES = ['/signin', '/invitation', '/invitations/accept'];

/**
 * Client half of entry routing. The Pages middleware (functions/_middleware.ts) handles page loads;
 * this covers in-app navigation and any host without that middleware, using the same GET /session answer.
 */
export function SessionGate() {
  const pathname = usePathname();
  const router = useRouter();
  const { state } = useSession();

  useEffect(() => {
    // Unsaved text keeps its page: the shell shows a banner with Sign in instead of replacing the screen.
    if (state.status === 'signedOut' && !OPEN_ROUTES.includes(pathname) && !hasUnsaved()) {
      router.replace(signinPathFor(pathname, window.location.search));
    } else if (state.status === 'ready' && pathname === '/signin') {
      let cancelled = false;
      void landingFor(state.session).then((path) => { if (!cancelled) router.replace(path); });
      return () => { cancelled = true; };
    }
  }, [state, pathname, router]);

  return null;
}
