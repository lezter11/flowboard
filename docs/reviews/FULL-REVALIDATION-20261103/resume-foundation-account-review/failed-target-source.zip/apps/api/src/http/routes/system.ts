import { Hono } from 'hono';
import { runMigrations } from '../../adapters/migrations.ts';
import { getPool } from '../../adapters/postgres.ts';
import { adminSecretMatches } from '../admin-secret.ts';
import { rateLimitBindingStatus } from '../../adapters/rate-limit-cloudflare.ts';

export const systemRoutes = new Hono<{ Variables: { requestId: string } }>();

systemRoutes.get('/status', async (c) => {
  const env = c.env as { DEV_LOGIN_SECRET?: string; HYPERDRIVE?: unknown; DATABASE_URL?: string } | undefined;
  const deployed = Boolean(env?.HYPERDRIVE || env?.DATABASE_URL);
  if (!adminSecretMatches(c.req.header('x-dev-secret'), env?.DEV_LOGIN_SECRET, deployed)) {
    return c.json({ error: { code: 'FORBIDDEN', message: 'Forbidden' } }, 403);
  }

  const pool = getPool(c);
  const rows = await pool.query('SELECT version, name, applied_at FROM schema_migrations ORDER BY version ASC');
  // Booleans only: which Cloudflare rate-limit bindings this runtime can see.
  return c.json({ data: { migrations: rows.rows, rateLimitBindings: rateLimitBindingStatus(c.env) } });
});

systemRoutes.post('/migrate', async (c) => {
  const env = c.env as { DEV_LOGIN_SECRET?: string; HYPERDRIVE?: unknown; DATABASE_URL?: string } | undefined;
  const deployed = Boolean(env?.HYPERDRIVE || env?.DATABASE_URL);
  if (!adminSecretMatches(c.req.header('x-dev-secret'), env?.DEV_LOGIN_SECRET, deployed)) {
    return c.json(
      {
        error: {
          code: 'FORBIDDEN',
          message: 'Invalid or missing administrative secret.',
          requestId: c.get('requestId'),
        },
      },
      403
    );
  }

  let pool;
  try {
    pool = getPool(c);
  } catch {
    pool = null;
  }
  if (!pool) {
    return c.json(
      {
        error: {
          code: 'DATABASE_UNAVAILABLE',
          message: 'No database connection pool available.',
          requestId: c.get('requestId'),
        },
      },
      503
    );
  }

  try {
    const result = await runMigrations(pool);
    return c.json({
      data: {
        status: 'ok',
        appliedCount: result.applied.length,
        applied: result.applied,
      },
    });
  } catch {
    return c.json(
      {
        error: {
          code: 'MIGRATION_FAILED',
          message: 'Database migration failed. Check server deployment configuration.',
          requestId: c.get('requestId'),
        },
      },
      500
    );
  }
});
