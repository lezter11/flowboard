# Flowboard security hardening roadmap (2026-10-29)

Status: proposal, scheduled **after** the UI/UX work. Nothing here is implemented unless the "Status" column says done. Quota and plan figures marked (unverified) come from memory and must be checked in the Cloudflare and Neon dashboards before we rely on them.

Plain-English model: Flowboard is a building. Identity is the front door, authorization is the lock on each room, the database is the vault, the edge (Cloudflare) is the perimeter, monitoring is the alarm and the guard, and the release process is how new locks get installed. This roadmap says which of those are strong, which are missing, and in what order to fix them.

Threat actors we plan for: a curious invited user trying to see another project; a stranger scanning the public site; an automated or AI-assisted attacker probing every endpoint cheaply and tirelessly; a request flood; a stolen laptop or leaked secret; a poisoned dependency or tool instruction (supply chain, prompt injection into our own agents).

## Where we stand

| Area | State | Evidence |
|---|---|---|
| Sign-in | Google OAuth only, no passwords; session cookie HttpOnly, Secure, SameSite=Lax; session token stored hashed | done; verified on UAT |
| Authorization | Project membership plus board grant; revocation on next request; independent review 8.985 pass | done; docs/reviews/BOARD-ACCESS-BETA-REREVIEW-20261029 |
| CSRF and CORS | Origin/Referer check on cookie writes; no wildcard origins | done |
| Browser hardening | CSP (with unsafe-inline trade-off), nosniff, frame deny, referrer and permissions policy | done on UAT |
| Input handling | Zod validation, parameterized SQL, body limits, bounded XLSX and image parsing | done; no attacker-style testing yet |
| Dependencies | zod advisory fixed; remaining npm audit items are build or dev tooling | done; recheck regularly |
| Edge abuse control | Cloudflare binding limiter does not enforce; PostgreSQL limiter in progress | open |
| Database isolation | App-level only; one broad database role; no row-level security | open |
| Monitoring and alerts | Documented as planned, not implemented | open |
| Attack-style testing | None beyond our own and one AI reviewer | open |
| Incident response | None written | open |

## Phase 1: before any production cutover (blockers)

| # | Work | Owner | Done when |
|---|---|---|---|
| S1 | Exact rate limit on sign-in, invitations, import, upload (PostgreSQL counters) | Backend, then Deployment verifies on UAT | burst test returns real 429s; recorded in docs/UAT_DEPLOY.md |
| S2 | Attack-style authorization matrix: for every endpoint, call it as stranger, other-project member, same-project member without board grant, viewer, and revoked user, with guessed or foreign IDs; expect 401, 403 or 404 and no data. Auto-generated from the route list so new routes cannot be forgotten | Backend, reviewed by Support | test suite fails when a route is missing from the matrix; all negative cases pass |
| S3 | Least-privilege database access: separate roles for app runtime, migrations and read-only reporting; runtime role cannot drop or alter tables; decide on PostgreSQL row-level security as a second wall (see decision D2) | Backend + Deployment | roles exist on UAT; tests run as the runtime role; decision recorded |
| S4 | Alerts that reach a human: uptime probe on /health/ready, 5xx rate, cron silence, auth failure spikes, database errors; implement what docs/MONITORING.md only plans | Deployment | a deliberately broken UAT triggers an alert you actually receive |
| S5 | Flood plan and quota check: confirm the Workers and Pages request quotas, Neon connection and compute limits (unverified figures), and what happens when each is exhausted; write the runbook (what to turn off, what to block, who to tell) | Deployment | docs/RUNBOOK_INCIDENTS.md reviewed; numbers verified in dashboards |
| S6 | Secrets hygiene pass: list every secret, owner, rotation steps; rotate the ones that appeared in chat or terminal history; confirm no secret in git history, logs or build output | Deployment + Support | docs/DEPLOY_SECRETS.md has rotation steps; secret scan clean |
| S7 | Production safety checks from docs/RELEASE_BETA.md: backup branch with data, migration state check, rollback ids | Deployment | all evidence recorded before the go |
| S8 | Independent re-review of the changes since 6e15bd0 that touch security (limiter, CI, headers, zod 4) by a stronger reviewer | Architect arranges | review record passes the gate |

## Phase 2: first month in production

| # | Work | Owner |
|---|---|---|
| S9 | Real security headers review under load of CSP reports; move toward nonce-based CSP if we ever move off static export | UI + Deployment |
| S10 | Dependency and supply-chain routine: weekly `npm audit`, lockfile review, pinned CI actions by SHA (done), no unreviewed postinstall scripts, update policy | Support |
| S11 | Penetration-style test by someone who did not build it: authenticated and unauthenticated, including IDOR (guessing another record's ID), mass assignment, cache and CORS tricks, file upload and XLSX abuse, invitation token handling | Support with a stronger model; consider a human tester before public launch |
| S12 | Logging that supports investigation: request ids, actor id, action, outcome, never tokens or card text; retention period; who can read | Backend + Deployment |
| S13 | Account and data lifecycle: user deletion or export on request, session revocation ("sign out everywhere"), invitation expiry, revoked-member cleanup | Backend |
| S14 | Backup and restore drill: restore a Neon branch to a point in time and boot the app against it; write the time it takes | Deployment |
| S15 | Abuse controls beyond rate limits: invitation spam, comment spam, mention floods, upload quotas per project | Backend |

## Phase 3: ongoing

- Custom domain with Cloudflare zone rules, bot protection and managed WAF rules when the product needs a real URL (a paid plan is needed for the 60-second rules we want; see docs/RATE_LIMITING.md).
- Durable Objects or an edge limiter if traffic outgrows database counters.
- Annual (or per major feature) independent security review; keep the review gate.
- Tabletop incident exercise twice a year: "the site is flooded", "a secret leaked", "a user reports seeing another team's board".

## Threats specific to AI agents

1. **AI-assisted attackers**: they scan faster and try every combination of IDs and roles. Defence is S2 (exhaustive negative tests), S1 (exact limits), S3 (second wall in the database) and S4 (we notice).
2. **Prompt injection into our own tooling**: web pages, issue text, third-party skills and tool outputs can contain instructions aimed at an AI agent. Controls we already follow: only the user's chat gives instructions; no installing third-party skills without the audit in docs/SKILLS_AUDIT.md; no secrets in chat; read-only reviews; dangerous actions need the user's yes. Add: never give an agent production credentials; use a deploy account with scoped tokens.
3. **Product features that call an LLM** (none today). If we add AI summaries or assistants later: treat every card, comment and imported cell as untrusted input to the model, never let model output trigger actions without a user check, never put other users' data into one prompt, and log prompts without personal data.
4. **Malicious automation as a user**: signed-in bots hammering the API. Controls: S1, S15, per-user (not only per-address) limits.

## Decisions needed from the user

- D1: custom domain now, later, or never (changes edge options; no cost today).
- D2: row-level security in PostgreSQL (strong second wall, more complexity and test work) or least-privilege roles only (simpler). Architect recommends roles first, RLS after the pen test shows the need.
- D3: whether to pay for a human penetration test before public launch.
- D4: alert destination (email, phone push) for S4.

## How we will know it worked

Each item has an evidence line. We do not mark an item done on a design or a passing unit test alone: S1 needs a burst test, S2 needs the generated matrix passing, S4 needs a real alert received, S14 needs a timed restore. Results go in docs/UAT_DEPLOY.md or the review folders, and the gate in BACKEND_REVIEW_GATE.md still applies to backend changes.

## Round 4a audit dispositions (Codex, frozen SHA 99ae250, recorded 2026-10-31)

Source: `docs/reviews/CODEX-AUDIT-20261031-D/` (0 critical, 1 high, 1 medium, 1 low; matrix 950 cells over 95 routes; focused API 61/61, lifecycle 7/7, web 145/145, contracts 108/108; full API suite interrupted, so no full-suite claim). Coverage was partial: areas D (names), E (email), G (database) and J (tests and docs) were not covered, and A, B, C, F, H, I were marked fail on the findings below. Not a clean bill of health.

| Finding | Disposition | Evidence needed to close |
|---|---|---|
| FB-R4-01 high: ownership transfer enabled, bypasses the target's project quota | **Fixed after the audited SHA**: `efc1e10` (B-20) returns 410 `TRANSFER_OWNERSHIP_RETIRED` (`apps/api/src/http/routes/workspaces.ts:163`); the lifecycle test was rewritten. | Round 4b re-test at a new frozen SHA |
| FB-R4-02 medium: PostCSS high and Next moderate advisory in the production tree (Undici high in dev) | **Accepted for the beta** (FB-AUD-04). Next 16 upgrade is a pre-public-launch item. | Dependency update commit and a clean `npm audit --omit=dev` |
| FB-R4-03 low: shared-project header can show the user's own workspace name (`active-project.ts:22-24`) | **In progress**: UI task S-22 (switcher and label). | UI commit plus a browser check with a shared-only account |
| Secret scan: 249 redacted gitleaks detections, not inspected | **Open, not certified.** Earlier manual review judged the known classes false positives (`Idempotency-Key` test headers, manifest hashes); this 249 count has not been triaged by the Architect. | Triage a sample and the classes; allowlist file for confirmed false positives |
| Full API suite interrupted; signed-in UAT flows not run; deploy log older than the audited SHA | **Open.** Round 4b runs the full suite with the access suite on; the owner runs `needs-owner.md` against the deployed UAT after the single combined deployment. | Round 4b report; owner checklist results |

## Haiku audits and dispositions (read-only, 2026-10-31, Architect-verified)

Source: `docs/reviews/HAIKU-AUDIT-20261031/`. Haiku output is a set of leads; each claim below was re-checked against the code by the Architect where stated.

| Area | Result | Disposition |
|---|---|---|
| Secret scan (Codex's 249 redacted gitleaks hits; Haiku classed 252 in the working tree) | 244 false positives (content hashes in audit manifests, `Idempotency-Key` test headers, fixtures); 8 to review: two lines of a local probe log holding an expired (10 minute) Google sign-in state cookie value, and six hits in the git-ignored, never-tracked `apps/web/.next` build cache. Raw JSON confirmed redacted. | **Closed: no confirmed exposure.** Cosmetic follow-up: redact the two probe-log lines. The 244 are Haiku's classification and were not each re-checked. |
| Authorization coverage | 99 registrations, no id-taking route lacks a project or board check. Checked by the Architect: `GET /boards/:id` checks existence before login (404 versus 401, low: ids are long random strings); dev-login is 404 on any deployed Worker (not a risk); my-tasks is authorized by the project access check (harmless). | **Open, low:** `GET /boards/:id` should authorize first (Backend, Release 2). 4 minor routes lack a test reference; 26 body schemas strip unknown keys silently (no pass-through found). |
| Error catalogue and messages | All catalogued codes have explicit web messages; two raw-text sites known (import rows, dev sign-in). Fixed: client-caused 400s no longer blame the server; name-step errors announced (`6dbedb1`). Two Haiku headline claims were wrong and rejected (image limit rounds to 10 MB; name inputs are linked with aria). | Closed for Release 1; import row messages are Release 2. |
| Docs drift | 19 rows; Architect confirmed `NAME_REQUIRED` missing from `ERROR_CATALOG` (the scan missed constant-thrown codes) and no `POST /api/v1/projects` row. Backend fixed the scan (now resolves constant codes; 105 codes), the catalog statuses, and `docs/API.md` (`b77fdad`, `8ef32b2`), with a mutation check for both literal and constant codes in a throwaway worktree. | Closed. Two rows rejected by Backend with reasons (unreachable defensive branch; nameSuffix producers already traced). |
